#ifndef _BASE_H
#define _BASE_H

#define TRUE         1
#define FALSE        0
#define OK           1
#define ERROR        0
#define OVERFLOW    -2
#define UNDERFLOW   -3

#define INFEASIBLIE -1
#endif
